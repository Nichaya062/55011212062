//
//  ViewController.swift
//  work1_week4
//
//  Created by iStudents on 2/6/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var one = 0
    var two = 0
    var three = 0
    
    @IBOutlet weak var oneLabel: UILabel!
    @IBOutlet weak var twoLabel: UILabel!
    @IBOutlet weak var threeLabel: UILabel!
    
    
    @IBAction func oneButton(sender: AnyObject) {
        one = one + 1
        oneLabel.text = String(format: "%d", one)
    }
    
    @IBAction func twoButton(sender: AnyObject) {
        two = two + 1
        twoLabel.text = String(format: "%d",two)
    }
    @IBAction func threeButton(sender: AnyObject) {
        three = three + 1
        threeLabel.text = String(format: "%d",three)
    }
    
    @IBAction func resetAllButton(sender: AnyObject) {
        oneLabel.text = "0"
        twoLabel.text = "0"
        threeLabel.text = "0"
        
        one = 0
        two = 0
        three = 0
    }
   
    
    


}

