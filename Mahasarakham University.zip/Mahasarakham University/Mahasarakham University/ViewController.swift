//
//  ViewController.swift
//  Mahasarakham University
//
//  Created by iStudents on 3/6/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController{

     //let cellIdentifier = "cellIdentifier"
    //var tableData = ["College of Music","College of Politics and Governance(COPAG)","Faculty of Architecture, Urban Design & Creative Arts","Faculty of Cultural Science","Faculty of Education","Faculty of Engineering","Faculty of Environment and Resource Studies","Faculty of Fine and Applied Arts","Faculty of Graduate Studies","Faculty of Humanities and Social Sciences","Faculty of Informatics","Faculty of Medicine","Faculty of Nursing","Faculty of Pharmacy","Faculty of Public Health","Faculty of Science"]
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
    }
    

    

  


}

