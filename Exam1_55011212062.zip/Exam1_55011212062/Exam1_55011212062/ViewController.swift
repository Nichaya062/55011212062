//
//  ViewController.swift
//  Exam1_55011212062
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let tipCalc = Tipcalcu(totalMid: 0.0, totalW: 0.0, totalFin: 0.0)
    
    func refreshUI() {
        totalMidterm.text = String(format: "%0.2f", tipCalc.totalMid)
        totalWork.text = String(format: "%0.2f", tipCalc.totalW)
        totalFinal.text = String(format: "%0.2f", tipCalc.totalFin)
        showGrade.text = ""
    }
    
    @IBOutlet weak var subject: UITextField!
    @IBOutlet weak var totalMidterm: UITextField!
    @IBOutlet weak var totalWork: UITextField!
    @IBOutlet weak var totalFinal: UITextField!
    @IBOutlet weak var showGrade: UITextView!
    
    @IBAction func sum(sender: AnyObject) {
        tipCalc.totalMid = Double((totalMidterm.text as NSString).doubleValue)
        tipCalc.totalW = Double((totalWork.text as NSString).doubleValue)
        tipCalc.totalFin = Double((totalFinal.text as NSString).doubleValue)
        
    }

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshUI()
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    
}


