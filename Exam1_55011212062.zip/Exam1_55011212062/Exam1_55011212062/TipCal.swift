//
//  TipCal.swift
//  Exam1_55011212062
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import Foundation
class Tipcalcu {
    
    var totalMid: Double
    var totalW: Double
    var totalFin: Double
    var sumtotal: Double{
        get {
            return (totalMid + totalW) + totalFin
        }
    }
    init(totalMid:Double,totalW:Double,totalFin:Double){
        self.totalMid = totalMid
        self.totalW = totalW
        self.totalFin = totalFin
        
    }
    
}